﻿
// dotnet aspnet-codegenerator razorpage -m Contact -dc ApplicationDbContext -udl -outDir Pages\Contacts --referenceScriptLibraries

using Final_Project.Authorization;
using Final_Project.Data;
using Final_Project.Model;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ContactManager.Data
{
    public static class SeedData
    {
        public static async Task Initialize(IServiceProvider serviceProvider, string testUserPw)
        {
            using (var context = new ApplicationDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            {
                // For sample purposes seed both with the same password.
                // Password is set with the following:
                // dotnet user-secrets set SeedUserPW <pw>
                // The admin user can do anything

                var adminID = await EnsureUser(serviceProvider, testUserPw, "jhanvi@georgian.com");
                await EnsureRole(serviceProvider, adminID, Constants.ContactAdministratorsRole);

                // allowed user can create and edit contacts that they create
                var managerID = await EnsureUser(serviceProvider, testUserPw, "jbhatt@georgian.com");
                await EnsureRole(serviceProvider, managerID, Constants.ContactManagersRole);

                SeedDB(context, adminID);
            }
        }

        private static async Task<string> EnsureUser(IServiceProvider serviceProvider,
                                                    string testUserPw, string UserName)
        {
            var userManager = serviceProvider.GetService<UserManager<IdentityUser>>();

            var user = await userManager.FindByNameAsync(UserName);
            if (user == null)
            {
                user = new IdentityUser
                {
                    UserName = UserName,
                    EmailConfirmed = true
                };
                await userManager.CreateAsync(user, testUserPw);
            }

            if (user == null)
            {
                throw new Exception("The password is probably not strong enough!");
            }

            return user.Id;
        }

        //internal static Task Initialize(IServiceProvider services)
        //{
        //    throw new NotImplementedException();
        //}

        private static async Task<IdentityResult> EnsureRole(IServiceProvider serviceProvider,
                                                                      string uid, string role)
        {
            var roleManager = serviceProvider.GetService<RoleManager<IdentityRole>>();

            if (roleManager == null)
            {
                throw new Exception("roleManager null");
            }

            IdentityResult IR;
            if (!await roleManager.RoleExistsAsync(role))
            {
                IR = await roleManager.CreateAsync(new IdentityRole(role));
            }

            var userManager = serviceProvider.GetService<UserManager<IdentityUser>>();

            //if (userManager == null)
            //{
            //    throw new Exception("userManager is null");
            //}

            var user = await userManager.FindByIdAsync(uid);

            if (user == null)
            {
                throw new Exception("The testUserPw password was probably not strong enough!");
            }

            IR = await userManager.AddToRoleAsync(user, role);

            return IR;
        }

        public static void SeedDB(ApplicationDbContext context, string adminID)
        {
            if (context.Contact.Any())
            {
                return;   // DB has been seeded
            }

            context.Contact.AddRange(
                new Contact
                {
                    Name = "Heena Kashyap",
                    Address = "123 Georgian",
                    City = "Barrie",
                    State = "ON",
                    Zip = "12345",
                    Email = "heena@gmail.com",
                    Status = ContactStatus.Approved,
                    OwnerID = adminID
                },
                new Contact
                {
                    Name = "Jhanvi Bhatt",
                    Address = "456 College Drive",
                    City = "Brampton",
                    State = "ON",
                    Zip = "67891",
                    Email = "jhanvi@georgian.com"
                },
             new Contact
             {
                 Name = "Sukhman Kaur",
                 Address = "1 central st",
                 City = "Barrie",
                 State = "ON",
                 Zip = "11028",
                 Email = "sukhman@yahoo.com"
             },
             new Contact
             {
                 Name = "Paras Bhatt",
                 Address = "1 Bayfield St",
                 City = "Barrie",
                 State = "ON",
                 Zip = "12689",
                 Email = "paras@example.com"
             },
             new Contact
             {
                 Name = "Jay Brahmbhatt",
                 Address = "2 Peregrine",
                 City = "Barrie",
                 State = "ON",
                 Zip = "23983",
                 Email = "jay@gmail.com.com"
             }
             );
            context.SaveChanges();
        }

    }
}